public interface Warung {
    int MAX = 10;
    int MIN = 0;

    void masuk();
    void tambah();
    void kuran();
    void pesan();

}